package xuxin.service.Impl;

import java.util.List;

import xuxin.dao.ItemsMapper;
import xuxin.domain.Items;
import xuxin.service.ItemsService;

public class ItemsServiceImpl implements ItemsService{

	private ItemsMapper itemsMapper;
	@Override
	public List<Items> findAll() {
		List<Items> list = itemsMapper.findAll();
		return list;
	}
	
}
