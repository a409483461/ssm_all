package xuxin.service;

import java.util.List;

import xuxin.domain.Items;

public interface ItemsService {
	List<Items> findAll();
}
