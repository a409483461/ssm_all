package xuxin.Controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import xuxin.domain.Items;
import xuxin.service.ItemsService;

@Controller
@RequestMapping("/")
public class ItemsController {
	private ItemsService itemsService;
	
	@RequestMapping("list")
	public String list(Model model){
		
		List<Items> list = itemsService.findAll();
		model.addAttribute("itemsList", list);
		return "itemsList";
		
	}
}
